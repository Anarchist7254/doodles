<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3b40d255785df68200c7a5e96c612d22',
      'native_key' => 'doodles',
      'filename' => 'modNamespace/9e1bb25a3ce0685ed3541b8ded611d42.vehicle',
      'namespace' => 'doodles',
    ),
  ),
);